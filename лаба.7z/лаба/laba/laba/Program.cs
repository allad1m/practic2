﻿using System;
using System.Collections.Generic;
using System.IO;

namespace TimeTrackingApp
{
    class Program
    {
        static string dataFilePath = "time_records.txt"; // Файл для хранения данных
        static Dictionary<string, List<TimeRecord>> records = new Dictionary<string, List<TimeRecord>>();

        static void Main(string[] args)
        {
            LoadData(); // Загрузка данных из файла

            while (true)
            {
                Console.WriteLine("=== Система учета рабочего времени ===");
                Console.WriteLine("1. Добавить сотрудника");
                Console.WriteLine("2. Отметить приход");
                Console.WriteLine("3. Отметить уход");
                Console.WriteLine("4. Просмотреть отчет");
                Console.WriteLine("5. Выход");
                Console.Write("Выберите действие: ");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        AddEmployee();
                        break;
                    case "2":
                        CheckIn();
                        break;
                    case "3":
                        CheckOut();
                        break;
                    case "4":
                        ShowReport();
                        break;
                    case "5":
                        SaveData(); // Сохранение данных перед выходом
                        return;
                    default:
                        Console.WriteLine("Неверный выбор. Попробуйте снова.");
                        break;
                }

                Console.WriteLine();
            }
        }

        // Добавление сотрудника
        static void AddEmployee()
        {
            Console.Write("Введите имя сотрудника: ");
            string name = Console.ReadLine();

            if (!records.ContainsKey(name))
            {
                records[name] = new List<TimeRecord>();
                Console.WriteLine($"Сотрудник {name} добавлен.");
            }
            else
            {
                Console.WriteLine("Сотрудник уже существует.");
            }
        }

        // Отметка прихода
        static void CheckIn()
        {
            Console.Write("Введите имя сотрудника: ");
            string name = Console.ReadLine();

            if (!records.ContainsKey(name))
            {
                Console.WriteLine("Сотрудник не найден.");
                return;
            }

            var record = new TimeRecord
            {
                Date = DateTime.Now.Date,
                CheckIn = DateTime.Now
            };

            records[name].Add(record);
            Console.WriteLine($"Приход {name} отмечен в {record.CheckIn.ToShortTimeString()}");
        }

        // Отметка ухода
        static void CheckOut()
        {
            Console.Write("Введите имя сотрудника: ");
            string name = Console.ReadLine();

            if (!records.ContainsKey(name) || records[name].Count == 0)
            {
                Console.WriteLine("Сотрудник не найден или не отмечал приход.");
                return;
            }

            var lastRecord = records[name][records[name].Count - 1];
            if (lastRecord.CheckOut != null)
            {
                Console.WriteLine("Уход уже был отмечен.");
                return;
            }

            lastRecord.CheckOut = DateTime.Now;
            Console.WriteLine($"Уход {name} отмечен в {lastRecord.CheckOut.Value.ToShortTimeString()}");
        }

        // Просмотр отчета
        static void ShowReport()
        {
            Console.WriteLine("\n=== Отчет о рабочем времени ===");
            foreach (var entry in records)
            {
                string name = entry.Key;
                var employeeRecords = entry.Value;

                Console.WriteLine($"\nОтчет для {name}:");
                foreach (var record in employeeRecords)
                {
                    TimeSpan? workTime = record.CheckOut - record.CheckIn;
                    string workTimeString = workTime?.ToString(@"hh\:mm") ?? "Уход не отмечен";

                    Console.WriteLine($"Дата: {record.Date.ToShortDateString()}, " +
                                      $"Приход: {record.CheckIn.ToShortTimeString()}, " +
                                      $"Уход: {(record.CheckOut?.ToShortTimeString() ?? "Не отмечен")}, " +
                                      $"Отработано: {workTimeString}");
                }
            }
        }

        // Сохранение данных в файл
        static void SaveData()
        {
            using (StreamWriter writer = new StreamWriter(dataFilePath))
            {
                foreach (var entry in records)
                {
                    string name = entry.Key;
                    var employeeRecords = entry.Value;

                    foreach (var record in employeeRecords)
                    {
                        writer.WriteLine($"{name}|{record.Date:yyyy-MM-dd}|{record.CheckIn:HH:mm:ss}|{record.CheckOut:HH:mm:ss}");
                    }
                }
            }
            Console.WriteLine("Данные сохранены.");
        }

        // Загрузка данных из файла
        static void LoadData()
        {
            if (!File.Exists(dataFilePath)) return;

            using (StreamReader reader = new StreamReader(dataFilePath))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    string[] parts = line.Split('|');
                    if (parts.Length != 4) continue;

                    string name = parts[0];
                    DateTime date = DateTime.Parse(parts[1]);
                    DateTime checkIn = DateTime.Parse(parts[2]);
                    DateTime? checkOut = DateTime.TryParse(parts[3], out DateTime co) ? co : (DateTime?)null;

                    var record = new TimeRecord
                    {
                        Date = date,
                        CheckIn = checkIn,
                        CheckOut = checkOut
                    };

                    if (!records.ContainsKey(name))
                    {
                        records[name] = new List<TimeRecord>();
                    }

                    records[name].Add(record);
                }
            }
            Console.WriteLine("Данные загружены.");
        }
    }

    // Класс для хранения записи о времени
    class TimeRecord
    {
        public DateTime Date { get; set; }
        public DateTime CheckIn { get; set; }
        public DateTime? CheckOut { get; set; }
    }
}